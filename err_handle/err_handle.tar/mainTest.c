/* 
    used for testing the err_handle.h header,

    may randomly change to check shit. Might not be implemented to test
    everything completely. Will decide on that when the time comes.
*/

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include "err_handle.h"



int main(int argc, char *argv[])
{

    errno = E2BIG;
    
    errMsg("This is my msg, int: %d, float: %f, long: %ld", (int)10, (float) 10.5, (long) 15);

    noerr_msg("noerrmsg");

    noerrExit("noerrExit");

    errnumExit(15, "string");

    exit(EXIT_SUCCESS);
} 
